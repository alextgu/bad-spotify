# Status

**Update this file when you finish something.** One line is enough. It's the
only place that says what's actually true right now.

Three states, and the middle one matters most:

| | Means |
|---|---|
| **Done** | Built, and someone has watched it work for real |
| **Built, unproven** | The code exists and runs on fake input. Nobody has pointed it at the real thing yet. **Assume it's broken until someone checks.** |
| **Not started** | — |

Last updated: 13 Aug 2026 (late) — after the mismatch refactor

---

## Where we are

| Part | State | Who |
|---|---|---|
| The loop holding it all together | Done | |
| Deciding when to change the song | Done | |
| Backup list when things break | Done | |
| Finding songs on Spotify | Built, unproven | |
| Playing songs on Spotify | Built, unproven | |
| Reading a photo into a description | Built, unproven | |
| Working out the opposite | Built, unproven | |
| The song list (47 songs) | Built, unproven | |
| Picking the funniest one | Built, unproven | |
| The voice | Built, unproven | |
| Video file as input | Built, unproven — now sampled by `videofeed` | |
| Recording a run for the site | Built, unproven | |
| Screens — DJ face and engineering view | Built, unproven | |
| Site — scaffold + demo ground | Built, unproven | |
| Site — launch page | Built, unproven | |
| Site — pipeline diagram | Not started | |
| Video sampler (`src/videofeed/`) | Done — 17 tests, incl. a real generated clip | |
| Engine (`service.py`) — one decision, no loop | Built, unproven | |
| Gradio app (`app.py`) | Built, unproven | |
| Naming and logo | Placeholder in `frontend/lib/brand.ts` | |
| Glasses | Not started — and not needed | |

"Built, unproven" is not a criticism. Everything was deliberately built to run
on stand-ins so nobody was blocked on accounts and hardware. But it does mean
**nothing has been seen working end to end with real accounts yet**, and that's
the single biggest risk to the demo.

---

## Done

- **The loop.** Look → check if anything changed → understand → flip it → pick a
  song → queue or cut in. Runs end to end today with fake versions of every piece.
- **When to change the song.** Won't thrash. Needs to see a change twice before
  reacting. Ignores itself when unsure. Queues by default, only cuts the music
  off when the room really changed *and* the current song has had a fair run.
- **Backup list.** If anything upstream dies, a pre-picked list of always-wrong
  songs plays anyway. It is never silent.
- **Tests.** 79 of them, each guarding a specific way the demo could break.
- **Timeouts on the model calls.** A slow answer is abandoned and retried
  rather than freezing the loop. A late answer is worth less than a fast fallback.

## What just changed

**The “cruelty” dial is gone.** It was a knob labelled *how far past
inappropriate to go*, and it described something the system doesn't do — the
product reads a mood and inverts a mood, full stop. How wrong the result turned
out is now **measured** afterwards and reported as `mismatch` (0–1), rather than
requested up front. Gone from the config, the CLI, the HUD, the JSON and the
site's types. The HUD now shows mismatch as a read-out with no slider.

An agent whose entire premise is that it ignores you should not take a
parameter for how much to ignore you.

**Three gaps that made the repo fail its own tests are closed.**
`EventBus.unsubscribe` (without it every `watch()` leaked a recorder onto a
module-level bus), `graph.decide_from_scene` (so the Gradio app runs the real
compiled graph instead of a second hand-rolled pipeline), and `force` — which
was being set but silently dropped, because LangGraph discards state keys that
aren't declared on the TypedDict.

## Built, but nobody has run it for real

Ordered by how badly it hurts if it turns out broken.

**1. Spotify — playing songs**
There's a one-command setup (`python scripts/spotify_setup.py`) that logs in,
checks the account is Premium, finds a speaker, looks up all 47 songs in advance,
tells you which ones it couldn't find, and plays a test track.
*To prove it:* run that script and hear a song come out of a speaker.
*Already covered:* 15 tests run the player against a stand-in Spotify — free
accounts, no devices awake, the named device missing, karaoke results, queue vs
interrupt, and a device falling asleep mid-call. The logic is sound.
*Still unknown:* whether real search returns what we expect for our 47 songs.
**Read the unresolved list when you run it.**

**2. Reading a photo**
Returns canned answers right now. Never been pointed at a real camera or a real
photo.
*To prove it:* show it five real photos and check the descriptions match.

**3. Picking the song**
Works, but only on the canned descriptions.
*To prove it:* run it on real photos and see whether the picks are funny.

**4. The voice**
Never run with a real account.
*To prove it:* hear it say a line out loud, over music, without lagging.

**5. The screen**
Two of them now, on the same server:
`/dj` is the presentation face — a reacting orb that takes on the room's colours,
the spoken line in big type, now-playing, and a compact reasoning ticker.
`/` is the engineering view we already had. Keep both: judges see the character,
we see the wiring.
*To prove it:* watch it drive off a real video on the projector.

**6. Video as input**
Feeds a recording in as though it were live — samples a frame every few seconds,
pulls the matching audio out with ffmpeg, and reports where in the video it is.
Tested against a generated clip, never against real footage.
*To prove it:* run it on an actual video someone filmed.
*Needs:* ffmpeg installed, otherwise it runs vision-only.

**7. The site**
`frontend/` — Next.js, TypeScript, Tailwind. Builds clean.
The launch page is done: minimal, deadpan, one idea per screen.
The demo ground works: it replays a recorded run against the video and pops up
each decision where the song lands.
Still missing: the pipeline diagram, and the real name.
*To prove it:* drop in real footage and a real recording, and walk someone through it.

**8. Recording a run**
`--record NAME` writes every decision to `data/sessions/NAME.json` — which song,
where in the video it starts, and why. This is what the presentation site will
read, so the site needs no backend and no keys.
*To prove it:* record a real clip and check the timings line up with the footage.

---

## The demo plan

Decided 13 Aug. We don't have Ray-Bans, so:

**Feed it a video file and let the backend treat it as live.** Same code path,
same timing, same everything — it just reads frames from a recording instead of
a camera. This is better than a live camera for presenting: it's repeatable, it
can't fail on stage, and we can pick footage that produces good jokes.

**Built.** `python run.py --video clip.mp4`. Needs ffmpeg for the audio.

**The look: a small DJ icon, like Spotify's DJ.** Not a dashboard. A character
that reacts, with a good voice. The current screen is an engineering view — it's
useful for us and it's the wrong thing to show a judge.

**Built, at `/dj`.** The reasoning stayed — as a compact ticker beside the orb
rather than the full dashboard. Showing it is a real differentiator and half of
why the technical work reads as serious, so it was worth keeping in a smaller form.

**A hosted site — this is our presentation format, not a product.** The spec:

- Explains the whole thing with a clear diagram
- Has a testing area: drop in a video, and it shows which songs it picked and
  *where in the video* each one plays
- Ships with a hardcoded sample video so it always works

**Mostly built.** The launch page and the demo area both work. Missing: the
pipeline diagram, and the real name. Don't sink more time into polish until the
backend has been proven with real footage — a beautiful site replaying a bad run
helps nobody.

**Audio on the site:** it names the song and people can look it up themselves.
For our own demo videos the music is overlaid onto the video. That sidesteps the
problem entirely — no visitor login, no licensing mess, no live playback to fail.

---

## Decisions we've already made

Don't re-open these without a reason.

- **13 Aug** — Queue by default, interrupt only when the room changed a lot and
  the song has had a run. Not a setting; the system decides per moment.
- **13 Aug** — Feed it a video file for the demo rather than a live camera.
- **13 Aug** — Look and feel is a DJ character, not a dashboard.
- **13 Aug** — The site is our presentation format, not a working product. Build
  it late, once the backend is proven.
- **13 Aug** — The site names songs rather than playing them; demo videos have
  the music overlaid. No visitor login, no licensing problem.
- **13 Aug** — Two screens, not one. The DJ face at `/dj` for judges, the
  engineering view at `/` for us. The reasoning stays visible on both — it's the
  difference between an agent and a shuffle button.
- **13 Aug** — The site is Next.js, in its own `frontend/` folder, and static.
  It replays a recorded run rather than calling the agent, so there's no backend
  to host and nothing live to fail.
- **Earlier** — One question to understand the scene, not one per detail.
- **Earlier** — Our own song list and scoring; Spotify is only the speaker.
  (Their music-analysis endpoints were shut off to new apps in 2024.)
- **Earlier** — Hand-picked famous songs over a huge database. The joke needs
  people to recognise the song.
- **Earlier** — No training our own model. No time, no need.
- **13 Aug** — Tagline: “The worst music for the best moments. And vice versa.”
- **13 Aug** — The site looks like a minimal product launch, played straight.
  The gap between the polish and what's being announced is the joke.
- **13 Aug** — Name is a placeholder in `frontend/lib/brand.ts` until we pick
  one. It should play off “DJ”. Note: Spotify's terms forbid “Spotify” in a
  product name, so the current working title can't ship publicly.
- **13 Aug** — No inversion dial. Always fully invert; measure and report the
  mismatch instead. `Verdict.mismatch` is an outcome, never an input.
- **13 Aug** — One decision path. Anything holding a scene already enters the
  same compiled graph via `decide_from_scene`; there is no second pipeline.
- **Earlier** — Glasses aren't needed to win.

---

## Next three things

1. **Run the Spotify setup script.** It's the only part that can quietly fail on
   the day, and it has the fiddliest setup. Everything else can be improved up to
   the deadline; this one either works or it doesn't.
2. **Point the photo-reader at real photos.** Everything downstream is judged on
   whether this is any good, and right now it's guesswork.
3. **Film a real demo clip and run it.** Everything needed to do this now exists.
   Whatever comes out of `--record` is the raw material for the site.

---

## Still open

- It'll repeat the same joke if left running a long time. No memory yet.
- Nobody's timed the real thing end to end.
- Nicheness is agreed as an idea but isn't scored or used anywhere.
- The genre map has now been scraped to `data/genre_map.json`, but still
  nothing reads it.
- ~~Two video readers.~~ **Resolved.** `capture/video.py` is now a thin adapter
  over `src/videofeed/`, so there's one video reader and one set of triggers.
  Video input now samples on scene cuts and audio onsets as well as on a clock,
  and those samples skip the local gate because the sampler already knows the
  world changed. `capture/gate.py` still serves the live webcam path, where we
  don't have the whole file up front.
- A calm scene used to deadlock: the change-detector suppressed repeat reads, so
  the "see it twice before acting" rule was never satisfied and nothing played.
  Fixed — a quiet tick now counts as evidence the scene is stable. Worth knowing
  in case something similar shows up elsewhere.
